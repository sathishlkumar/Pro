import java.util.*;
class Bank {
	float balance;
	float lastTransaction;
	String customerName;
	String customerId;
	Scanner sc=new Scanner(System.in);
	Bank(String name,String id)
	{
		customerName=name;
		customerId=id;
	}
	void deposit(float money)
	{
		if(money!=0)
		{
		balance+=(int)money;
		lastTransaction=(int)money;
		}
	}
	void withdraw(float money)
	{
		if(money!=0 && money <= balance)	
		{
		balance-=(int)money;
		lastTransaction=-(int)money;	
		}
	}
	void transaction()
	{
		if(lastTransaction > 0 )
		{
			System.out.println("Deposited-amount : " + lastTransaction);
		}
		else if(lastTransaction < 0)
		{
			System.out.println("Withdrawn: " + (-lastTransaction));
		}
		else {
			System.out.println("No transaction history Noted.");
		}
	}
	void display()
	{
		char choice='\0';
		System.out.println("Customer-Name: "+ customerName);		
		System.out.println("Customer-Id: "+ customerId);
		System.out.println("a.Balance");
		System.out.println("b.Deposit");
		System.out.println("c.Withdraw");
		System.out.println("d.LastTransaction");
		System.out.println("e.Exit");
		do{
			System.out.println("Enter an choice:");
			choice=sc.next().charAt(0);
			System.out.println("\n");
			float n;
			switch(choice)
			{
				case 'a':
					System.out.println("Balance = " + (float)balance + "\n");
					break;
				case 'b':
					System.out.println("Enter the Deposit amount:");
					n=sc.nextFloat();
					deposit(n);
					System.out.println("\n");
					break;
				case 'c':
					System.out.println("Enter the Withdrawal amount:");
					n=sc.nextFloat();
					withdraw(n);
					System.out.println("\n");
					break;
				case 'd':
					transaction();
					System.out.println("\n");
					break;
				case 'e':
					System.out.println("\n");
					break;
				default :
					System.out.println("Invalid choice");
					System.out.println("\n");
					break;
			}
		}while(choice != 'e');
		System.out.println("Thank you.");
	}
}
public class Main{
	public static void main(String args[])
	{
		String name,id;
		System.out.println("Enter the customerName and customerId:");
		Scanner sc=new Scanner(System.in);
		name=sc.next();
		id=sc.next();
		Bank obj=new Bank(name,id);
		obj.display();
	}
}

